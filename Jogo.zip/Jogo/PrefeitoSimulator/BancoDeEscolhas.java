package PrefeitoSimulator;
import java.util.*;

// Classe responsável por armazenar todos os Eventos presentes no Jogo
public class BancoDeEscolhas {
    // Eventos Normais
    public static List<Evento> eventosNormais() {
        List<Evento> eventos = new ArrayList<>();

        eventos.add(new Evento("Uma grande indústria de montagem de carros elétricos quer se instalar às margens do principal rio da cidade, a montadora estima que vai ter que contratar até 3% da população, só com essa notícia pessoas das cidades vizinhas já começam a vir para sua cidade em busca dos futuros empregos existe uma parte da população que teme que essa montadora polua de alguma forma o rio, um grupo de analistas ambientais contratados pela montadora diz que o impacto ambiental vai ser baixo e ativistas ambientais são contra a instalação da montadora alegando que a montadora vai despejar químicos nos rios.",
            new Escolha("Negar instalação", +5, -15, -15, -20,
            "Você nega a montadora, perde investimentos. Parte da população critica a decisão.\n\n +5 de Meio Ambiente\n -15 de Fundos Econômicos\n -15 de População \n -20 de Aprovação Pública"),

            new Escolha("Aprovar com o regimento padrão", -15, +25, +10, +10,
            "A economia cresce rapidamente, 3% da população foi contratada, ao contrário do que os críticos diziam a montadora sequer mexe com químicos, uma montadora apenas monta e seus resíduos são poucos e pontuais .\n\n -15 de Meio Ambiente \n +25 de Fundos Econômicos \n +10 de População \n +10 de Aprovação Pública"),

            new Escolha("Aprovar com regras ambientais especiais", 0, +15, +10, +10,
            "A montadora é instalada com sucesso e a regulação garante que o rio fique intacto. A cidade se torna um polo de empregos verdes e a economia gira de forma limpa!\n\n 0 de Meio Ambiente \n +15 de Fundos Econômicos \n +10 de População \n +10 de Aprovação Pública")
        ));

        eventos.add(new Evento("O sistema de saneamento básico da nossa metrópole atingiu o seu limite operacional e está à beira de um colapso. Moradores de diversos bairros relatam vazamentos de esgoto a céu aberto, e laudos técnicos indicam que as falhas são tanto pontuais quanto estruturais. Especialistas alertam que, se nada for feito, o esgoto não tratado pode alcançar o lençol freático e os rios locais, causando um desastre ambiental e de saúde pública sem precedentes na nossa gestão.", "Sistema Saneamento.png",
            new Escolha("Melhorias pontuais focando nas áreas com defeitos não estruturais", +10, -10, +5, +5,
            "As equipes da prefeitura contêm os vazamentos superficiais, aliviando o mau cheiro e os transtornos imediatos. O meio ambiente respira melhor provisoriamente, mas o custo pesa nos cofres e o problema estrutural profundo nas tubulações antigas permanece como uma bomba-relógio para o futuro.\n\n +10 de Meio Ambiente \n -10 de Fundos Econômicos \n +5 de População \n +5 de Aprovação Pública"),

            new Escolha("Adiar investimentos", -25, +5, -15, -20,
            "A prefeitura decide não gastar agora, economizando recursos preciosos. Porém, a infraestrutura cede completamente: esgoto bruto contamina os rios, surtos de doenças se espalham rapidamente, a população se revolta e muitos começam a se mudar da cidade em busca de condições dignas.\n\n -25 de Meio Ambiente\n +5 de Fundos Econômicos\n -15 de População \n -20 de Aprovação Pública"),

            new Escolha("Reforma completa do sistema, com foco sustentável", +20, -20, +10, +20,
            "Uma obra faraônica e ecológica é iniciada. Apesar do alto custo inicial que drena os cofres públicos, a nova rede conta com tratamento avançado. Os rios começam a despoluir, as doenças despencam e a população exalta sua corajosa visão de futuro sustentável.\n\n +20 de Meio Ambiente \n -20 de Fundos Econômicos \n +10 de População \n +20 de Aprovação Pública")
        ));

        eventos.add(new Evento("A frota de veículos da cidade cresceu de forma descontrolada nos últimos anos, transformando as principais vias em estacionamentos a céu aberto durante os horários de pico. A poluição sonora e a emissão de gases de efeito estufa dispararam, criando uma névoa cinza sobre o centro comercial. Moradores estão exaustos de perder horas no trânsito, e o setor produtivo pressiona a prefeitura por uma solução urgente para o caos logístico.", "Transito.jpg",
            new Escolha("Ignorar", -10, -5, -20, -25,
            "A imobilidade urbana se torna a marca registrada da sua gestão. A poluição do ar piora consideravelmente devido aos motores ligados, pequenos negócios sofrem com atrasos logísticos e a fúria dos motoristas se converte em uma queda brutal na sua aprovação popular.\n\n -10 de Meio Ambiente \n -5 de Fundos Econômicos \n -20 de População \n -25 de Aprovação Pública"),

            new Escolha("Expandir transporte sustentável", +15, -10, +10, +15,
            "Com a criação de corredores exclusivos para ônibus elétricos e uma vasta malha de ciclovias, a população adota novos modais. Embora os custos pesem no tesouro municipal, a cidade volta a fluir pacificamente, o ar fica mais limpo e a qualidade de vida atrai residentes.\n\n +15 de Meio Ambiente \n -10 de Fundos Econômicos \n +10 de População \n +15 de Aprovação Pública"),

            new Escolha("Construir mais avenidas", -20, -20, +15, +10,
            "Você decide desapropriar áreas e desmatar parques urbanos para rasgar novas e largas avenidas para carros. O trânsito flui inicialmente atraindo mais moradores para as periferias, mas o custo da obra é altíssimo e a destruição de áreas verdes afeta gravemente o microclima da cidade.\n\n -20 de Meio Ambiente \n -20 de Fundos Econômicos \n +15 de População \n +10 de Aprovação Pública")
        ));

        eventos.add(new Evento("Fiscais do município descobriram que um grande complexo industrial tem despejado efluentes tóxicos silenciosamente em uma área de preservação permanente. Antes que a multa seja aplicada, os executivos da empresa solicitam uma reunião a portas fechadas. Eles oferecem uma quantia milionária por debaixo dos panos, pedindo em troca que a prefeitura 'feche os olhos' e conceda uma licença ambiental fraudulenta para a continuidade das operações.", "Acordo ilegal.png",
            new Escolha("Recusar e chantagear a empresa ameaçando fazer uma denúncia", +10, +25, 0, 0,
            "Você utiliza a fiscalização para forçar a empresa a paralisar o despejo imediatamente e depositar o 'acordo' como uma doação não oficial para o tesouro. O meio ambiente é poupado da degradação, a prefeitura enriquece, mas a manobra obscura e sigilosa não traz reconhecimento público.\n\n +10 de Meio Ambiente \n +25 de Fundos Econômicos"),

            new Escolha("Recusar e denunciar", +15, +10, +5, +20,
            "Sua gestão expõe o esquema em rede nacional! A empresa é severamente punida, interrompendo a degradação, e as pesadas multas legais reforçam o caixa da cidade. A população celebra intensamente a sua honestidade implacável e sua popularidade dispara junto com o orgulho cívico.\n\n +15 de Meio Ambiente\n +10 de Fundos Econômicos \n +5 de População \n +20 de Aprovação Pública"),

            new Escolha("Aceitar", -25, +35, 0, -25,
            "O dinheiro sujo entra silenciosamente para inflar os projetos municipais futuros. No entanto, o vazamento de toxinas continua em ritmo acelerado, devastando a fauna local. Pior ainda, o Ministério Público descobre o suborno, gerando um escândalo vergonhoso que afunda sua reputação.\n\n -25 de Meio Ambiente \n +35 de Fundos Econômicos \n -25 de Aprovação Pública")
        ));

        eventos.add(new Evento("O mercado global entrou em pânico devido a um choque abrupto na oferta de petróleo refinado, fazendo os preços dos combustíveis e insumos dispararem de forma caótica. A inflação ameaça corroer o poder de compra dos seus cidadãos e paralisar a cadeia de abastecimento da cidade. Conselheiros econômicos alertam que medidas drásticas e imediatas são necessárias para evitar o fechamento em massa de empresas e um colapso urbano total.", "Crise economica global.jpg",
            new Escolha("Criar refinarias de petróleo", -25, +30, +15, +15,
            "Você atrai indústrias petroquímicas afrouxando as leis ambientais. A cidade nada contra a maré da crise, lucrando de forma exorbitante e gerando milhares de empregos salvadores para multidões. Porém, as chaminés transformam o céu local em uma grossa cortina de fumaça adoecedora.\n\n -25 de Meio Ambiente\n +30 de Fundos Econômicos \n +15 de População \n +15 de Aprovação Pública"),

            new Escolha("Cortar gastos ambientais", -20, +15, -15, -20,
            "Para equilibrar as contas, os programas de proteção verde e manutenção de parques são extirpados. A prefeitura sobrevive fiscalmente à crise num primeiro momento, mas a negligência transforma áreas verdes em verdadeiros lixões, causando nojo e estimulando o êxodo populacional.\n\n -20 de Meio Ambiente \n +15 de Fundos Econômicos \n -15 de População \n -20 de Aprovação Pública"),

            new Escolha("Investir agressivamente em economia verde", +20, +15, +10, +20,
            "Ao invés de recuar, você dobra a aposta no futuro injetando capital em energia limpa e mobilidade alternativa. A cidade se blinda estruturalmente contra o choque do petróleo, atraindo startups e tornando-se um oásis de inovação verde que gera riqueza limpa e profundo orgulho popular.\n\n +20 de Meio Ambiente \n +15 de Fundos Econômicos \n +10 de População \n +20 de Aprovação Pública")
        ));

        eventos.add(new Evento("Milhares de jovens, ativistas e cidadãos comuns tomaram as ruas do centro cívico, bloqueando as vias de acesso à prefeitura e paralisando a cidade. O movimento exige que sua gestão decrete estado de emergência climática e aprove um pacote rigoroso de transição energética imediata. Os ânimos estão exaltados, a imprensa nacional cobre o evento ao vivo e a resposta da prefeitura definirá o futuro político e social do seu mandato.", "Protestos ambientais.jpg",
            new Escolha("Ignorar, uma hora os protestos vão dispersar", 0, 0, -20, -25,
            "Você se tranca no gabinete e aposta na exaustão dos manifestantes. A tática falha miseravelmente, mantendo a cidade paralisada por semanas. Sem qualquer pingo de diálogo, o ressentimento popular explode, destruindo sua imagem e levando jovens talentos a abandonarem a cidade.\n\n -20 de População \n -25 de Aprovação Pública"),

            new Escolha("Dialogar e seguir suas exigências", +10, -15, +15, +25,
            "Você desce à praça pública, ouve as lideranças e assina um termo de compromisso ambiental ambicioso. O pacote de transição exige um rombo nos cofres para sua execução, mas a população e os ativistas se sentem verdadeiramente representados, fortalecendo as raízes democráticas da cidade.\n\n +10 de Meio Ambiente \n -15 de Fundos Econômicos \n +15 de População \n +25 de Aprovação Pública"),

            new Escolha("Reprimir para que não aumente", -5, 0, -15, -35,
            "A tropa de choque e jatos d'água são acionados. Imagens de truculência contra defensores da natureza circulam mundialmente. O movimento é sufocado, mas sua aprovação despenca para o abismo, taxando você como inimigo do futuro e afugentando investidores humanos.\n\n -5 de Meio Ambiente \n -15 de População \n -35 de Aprovação Pública")
        ));

        eventos.add(new Evento("A demanda energética da nossa metrópole ultrapassou a capacidade das obsoletas usinas termoelétricas locais, causando apagões frequentes em zonas críticas. O Ministério do Meio Ambiente deu um ultimato para o desligamento das matrizes superpoluentes. Uma nova megafonte de energia precisa ser decidida e financiada rapidamente para evitar o apagão total, mas a sua escolha determinará o impacto ambiental e econômico de toda uma geração.", "Crise Energética.png",
            new Escolha("Energia nuclear dividida com outras cidades", +25, -40, +30, +30, 
            "Um consórcio viabiliza uma usina atômica de última geração. O investimento inicial suga agressivamente suas reservas, mas a energia torna-se totalmente limpa, constante e absurdamente abundante. Indústrias migram em massa para a região iluminada e o povo festeja a fartura.\n\n +25 de Meio Ambiente \n -40 de Fundos Econômicos \n +30 de População \n +30 de Aprovação Pública"),

            new Escolha("Energia solar integrada (telhados públicos e indústrias)", +20, -15, +10, +20,
            "Uma política forte de painéis fotovoltaicos pulveriza a geração de energia sobre galpões e órgãos públicos. O município financia a base com custos aceitáveis. Sem derrubar uma única árvore, a malha garante autossuficiência moderada e despenca as contas de luz, coroando sua gestão verde.\n\n +20 de Meio Ambiente \n -15 de Fundos Econômicos \n +10 de População \n +20 de Aprovação Pública"),

            new Escolha("Energia hidrelétrica (pequena represa)", -10, -15, +10, +20,
            "Você autoriza o alagamento de um vale adjacente para uma nova represa. A construção consome uma verba significativa e erradica uma zona de flora vital, desagradando biólogos locais. Contudo, a estabilidade elétrica gerada pacifica o comércio e traz segurança para os novos habitantes da cidade.\n\n -10 de Meio Ambiente \n -15 de Fundos Econômicos \n +10 de População \n +20 de Aprovação Pública")
        ));

        eventos.add(new Evento("Alertas máximos soam na Defesa Civil: chuvas torrenciais severas combinadas com desmatamento antigo nas encostas desencadearam deslizamentos de terra mortais e enchentes avassaladoras nas regiões leste da cidade. Rios transbordaram, arrastando veículos e destruindo bairros inteiros. O centro de operações de crise aguarda nervosamente suas ordens para decidir qual deve ser a prioridade absoluta nos esforços de resgate desta noite.", "Desastre ambiental.jpg",
            new Escolha("Resposta econômica, focando no pós-desastre", -25, +10, -35, -40,
            "Focando em blindar os cofres, você segura as operações aéreas caras e confia os custos da reconstrução aos seguros civis e fundos futuros. A inércia resulta numa catástrofe humana terrível. Bairros inteiros escoam na lama, vidas se perdem e o povo jura vingança contra sua frieza política.\n\n -25 de Meio Ambiente\n +10 de Fundos Econômicos\n -35 de População \n -40 de Aprovação Pública"),

            new Escolha("Resposta rápida, priorizar vidas a todo o custo ", -10, -35, 0, +40,
            "Botes, helicópteros governamentais e até contratação de equipes civis mercenárias: você não poupa um centavo público para resgatar até a última alma ilhada. A força da água destrói as reservas ecológicas, e o tesouro é dizimado, mas as pessoas sobrevivem e tratam você como o herói absoluto.\n\n -10 de Meio Ambiente \n -35 de Fundos Econômicos \n +40 de Aprovação Pública"),

            new Escolha("Resposta eficiente, salvar o máximo possível de tudo", +10, -20, -15, +15,
            "De forma pragmática, você divide os esforços: tenta resgatar moradores em áreas densas e envia equipes menores para preservar as contenções ambientais que sobram. As finanças são abaladas sem excessos, porém a diluição dos esforços acarreta perdas residenciais e frustração parcial dos cidadãos afetados.\n\n +10 de Meio Ambiente \n -20 de Fundos Econômicos \n -15 de População \n +15 de Aprovação Pública")
        ));

        eventos.add(new Evento("O aterro sanitário da nossa cidade está prestes a operar acima da capacidade máxima permitida por lei, exalando gases nocivos e ameaçando contaminar seriamente o solo. Comitês de desenvolvimento urbano lhe entregaram um projeto completo para a criação de um moderno sistema municipal de coleta seletiva e reciclagem ativa. A decisão de encampar, testar de leve ou ignorar essa logística mudará nossa relação com os resíduos urbanos.", "coleta seletiva.png",
            new Escolha("Projeto piloto", +10, -5, +5, +10,
            "Você adquire pequenos caminhões híbridos e inicia a separação em pólos comerciais de luxo. A implantação custa pouco, reduz levemente a velocidade do aterro e as propagandas de sustentabilidade ganham a simpatia popular para um projeto embrionário que dá seus primeiros passos sólidos.\n\n +10 de Meio Ambiente \n -5 de Fundos Econômicos \n +5 de População \n +10 de Aprovação Pública"),

            new Escolha("Ignorar", -20, 0, -10, -15,
            "Sem priorizar a pasta, os resíduos continuam indo para o mesmo buraco. O aterro vaza o chorume contendo metais pesados para os riachos, e as montanhas de lixo produzem nuvens de insetos em bairros periféricos, gerando surtos de doenças e forte decepção entre as famílias residentes.\n\n -20 de Meio Ambiente\n -10 de População\n -15 de Aprovação Pública"),

            new Escolha("Implementar totalmente e criar usinas de reciclagem", +30, +10, +15, +20,
            "É a revolução circular na cidade inteira! Usinas monumentais separam metais, papel e plástico para revenda industrial pesada. Em pouco tempo, o projeto se autossustenta e gera lucros formidáveis para o município, enterrando de vez o passivo ambiental e modernizando a civilização local.\n\n +30 de Meio Ambiente \n +10 de Fundos Econômicos \n +15 de População \n +20 de Aprovação Pública")
        ));
        
        eventos.add(new Evento("O sindicato das indústrias solares e a câmara dos vereadores pautaram uma legislação ousada: subsidiar a implantação de painéis fotovoltaicos em propriedades residenciais de toda a cidade. A ideia visa transformar o município em uma enorme central solar descentralizada e sustentável. Contudo, secretários da fazenda tremem com o medo de que o financiamento estatal crie um verdadeiro abismo nos cofres a curto prazo caso o subsídio seja mal calibrado.", "solar residencial.png",
            new Escolha("Não incentivar", -15, +5, -5, -10,
            "Você exerce seu poder de veto para blindar a arrecadação das loucuras legislativas. No entanto, o apagão da inovação enfurece as camadas modernas da sociedade. As famílias seguem asfixiadas pelas contas de termoelétricas poluentes e a cidade mantém a mesma fumaça no céu de antes.\n\n -15 de Meio Ambiente\n +5 de Fundos Econômicos\n -5 de População\n -10 de Aprovação Pública"),

            new Escolha("Bancar instalação parcial através de financiamento público", +25, -10, +15, +20,
            "Você autoriza um generoso subsídio governamental cobrindo boa parte das placas, com famílias parcelando o restante em taxas suaves. Telhados escuros viram vidros azuis rapidamente, descarbonizando o ar local e barateando o custo de vida, virando um grande imã populacional à prova do futuro.\n\n +25 de Meio Ambiente\n -10 de Fundos Econômicos\n +15 de População\n +20 de Aprovação Pública"),

            new Escolha("Incentivo apenas em redução de burocracia", +10, 0, +5, +10,
            "Usando astúcia política, você zera todos os alvarás e barreiras de aprovação para sistemas solares civis, mas não gasta verba de apoio direto. O pacote gratuito motiva proprietários da classe alta a instalarem sozinhos, plantando a semente da mudança sem causar nenhuma despesa aos cofres.\n\n +10 de Meio Ambiente\n 0 de Fundos Econômicos\n +5 de População\n +10 de Aprovação Pública")
        ));

        eventos.add(new Evento("Relatórios urgentes da companhia hídrica confirmaram um aumento explosivo no consumo per capita de água na cidade devido a um novo ciclo de expansão industrial aliado a ondas de calor sem precedentes. O nível dos nossos principais mananciais naturais está cedendo a olhos vistos. Se o prefeito não adotar diretrizes de mitigação antes da próxima estação seca, os bairros periféricos logo abrirão as torneiras e encontrarão apenas o barulho dos canos vazios.", "Consumo de agua elevado.jpg",
            new Escolha("Aumentar os reservatórios", -15, -25, +20, +20,
            "Você comanda enormes retroescavadeiras para alagar vales profundos criando novas bacias hidrográficas artificiais monumentais. Florestas desaparecem submersas e as finanças secam no processo de obra pesada, porém a água transborda para o povão, que glorifica a faraônica construção que o salva da sede.\n\n -15 de Meio Ambiente \n -25 de Fundos Econômicos \n +20 de População \n +20 de Aprovação Pública"),

            new Escolha("Campanhas educativas", +10, -5, +5, +10,
            "Equipes de publicidade inundam os meios de comunicação implorando que as pessoas lavem carros com baldes e reduzam o tempo no chuveiro. O método tira fundos modestos para propaganda, mas ajuda a retardar o fundo dos poços naturais, proporcionando alívio moderado que a sociedade aceita de bom grado.\n\n +10 de Meio Ambiente\n -5 de Fundos Econômicos\n +5 de População\n +10 de Aprovação Pública"),

            new Escolha("Políticas de controle e reúso industrial", +25, +5, +5, +15,
            "Uma diretriz de mestre é imposta: as gigantescas indústrias só podem operar usando água de reúso tratada que a cidade irá revender para elas! A medida cirúrgica preserva as nascentes de água potável limpas e garante lucro para os impostos municipais, assegurando a harmonia sustentável do sistema.\n\n +25 de Meio Ambiente\n +5 de Fundos Econômicos\n +5 de População\n +15 de Aprovação Pública")
        ));

        eventos.add(new Evento("Uma bomba-relógio política explodiu em suas mãos. Uma investigação independente descobriu um elaborado esquema de superfaturamento e fraudes licitatórias justamente na Secretaria do Meio Ambiente, envolvendo aliados do seu círculo de confiança que lideravam a reforma das reservas da cidade. Documentos manchados foram divulgados à imprensa e a oposição exige um processo formal de cassação do seu governo na câmara enquanto a praça enche de manifestantes.",
            new Escolha("Negar envolvimento", 0, +5, -15, -25,
            "Você mantém o tom agressivo, acusa a mídia de fake news e blinda os envolvidos. O pacto de silêncio mantém acordos políticos lucrativos ativos, mas o cinismo evidente repulsa os trabalhadores locais. As ruas ficam enojadas e a revolta popular amarga completamente sua capacidade de liderança moral.\n\n +5 de Fundos Econômicos\n -15 de População\n -25 de Aprovação Pública"),

            new Escolha("Investigar e punir os responsáveis", 0, -10, +10, +25,
            "Dando um passo radical para preservar a transparência, você abre todos os sigilos e entrega seus aliados às autoridades de frente para as câmeras. A turbulência afugenta contratos vitais e arranha a economia estatal, mas o eleitor perdoa e festeja a postura irredutível do governante honesto da cidade.\n\n -10 de Fundos Econômicos\n +10 de População\n +25 de Aprovação Pública"),

            new Escolha("Abafar o caso com suborno", 0, -25, -10, -30,
            "Dinheiro público é drenado na calada da noite para silenciar vereadores e promotores da base aliada num desespero absurdo. Infelizmente, uma testemunha não aceita o suborno, vazando um segundo áudio onde você próprio aparece ordenando as propinas. O desastre joga tudo pelos ares, esvaziando a cidade e seu cargo.\n\n -25 de Fundos Econômicos \n -10 de População \n -30 de Aprovação Pública")
        ));

        eventos.add(new Evento("Um mega-conglomerado multinacional enxergou o potencial inexplorado da nossa metrópole e acaba de apresentar um plano de construção faraônico. O projeto engloba plantas industriais inteligentes, enormes centros de distribuição e complexos comerciais que prometem erradicar o desemprego para sempre na região. Em contrapartida, eles exigem o desmatamento lícito de um largo bosque periférico e pedem agressivos cortes de impostos em uma mesa de negociações dura.", "investidor.jpg",
            new Escolha("Negociar condições equilibradas", -5, +15, +10, +15,
            "Em embates ferozes e demorados na mesa do gabinete, você arranca a promessa de construção compensatória de parques e isenções leves de ISS. As firmas se instalam com vigor moderado na cidade. O meio ambiente sofre cortes sutis nas bordas, enquanto fundos e novos habitantes chegam pacificamente de longe.\n\n -5 de Meio Ambiente\n +15 de Fundos Econômicos\n +10 de População\n +15 de Aprovação Pública"),

            new Escolha("Recusar proposta", +10, -20, -10, -15,
            "Colocando a inviolabilidade verde da cidade como muralha primária, você barra o bilionário conglomerado e rasga os contratos em público. As majestosas árvores da periferia agradecem eternamente, mas o setor econômico entra em luto fúnebre pelas vagas de emprego sumidas, empurrando a população para a pobreza desolada.\n\n +10 de Meio Ambiente\n -20 de Fundos Econômicos\n -10 de População\n -15 de Aprovação Pública"),

            new Escolha("Aceitar com incentivos fiscais", -20, +25, +15, +10,
            "O tapete vermelho é completamente estendido. Sem impostos, a corporação desmata velozmente com motosserras vorazes erguendo o maior pólo empresarial do país nas cinzas do bosque. O dinheiro preenche todo o mercado local de oportunidades agressivas de consumo, escondendo a lágrima silenciosa dos animais expulsos.\n\n -20 de Meio Ambiente\n +25 de Fundos Econômicos\n +15 de População\n +10 de Aprovação Pública")
        ));

        eventos.add(new Evento("Produtores renomados querem realizar a edição de décimo aniversário de um gigantesco festival de música eletrônica e pop dentro da reserva ambiental controlada de maior prestígio na nossa metrópole. O choque logístico trará uma invasão de turistas dispostos a injetar dólares nos hotéis da cidade durante uma semana mágica, porém, biólogos relatam medo paralisante quanto ao descarte impiedoso de plásticos, copos e superlotação que devastará os canteiros protegidos.", "festival cultural.jpg",
            new Escolha("Evento moderado", -5, -10, +10, +15,
            "O alvará impõe limite de lotação baixa e a prefeitura arca compulsoriamente com taxas pesadas de limpezas pós-evento. A festa se limita às clareiras seguras, o chão e os arbustos sofrem com o lixo esporádico e música alta, mas o turista comum adora o entretenimento oferecido, trazendo popularidade limpa.\n\n -5 de Meio Ambiente\n -10 de Fundos Econômicos\n +10 de População\n +15 de Aprovação Pública"),

            new Escolha("Investir pesado no evento", -15, -30, +20, +30,
            "A prefeitura gasta comícios e milhões na criação de vias de acesso maciças e palcos monstruosos. É a semana mais inesquecível de toda a década local! Pessoas migram para viver perto desse agito alucinado, porém os jardins do parque são terraplanados pelos palcos e a tesouraria amarga um rombo profundo festivo.\n\n -15 de Meio Ambiente\n -30 de Fundos Econômicos\n +20 de População\n +30 de Aprovação Pública"),

            new Escolha("Cancelar", +5, +15, -15, -20,
            "Priorizando santuários e pássaros em cima de entretenimento, o festival é lacrado antes de brotar. A paz inquebrável da mata atrai insetos e verde de volta de maneira belíssima e os patrocinadores pagam ricas multas de encerramento para o governo. A classe mais nova, porém, chora no tédio amargo e muitos repudiam sua severidade antiquada.\n\n +5 de Meio Ambiente\n +15 de Fundos Econômicos\n -15 de População\n -20 de Aprovação Pública")
        ));

        eventos.add(new Evento("Os prontos-socorros das UPAs e da nossa rede principal de hospitais atingiram níveis aterrorizantes de calamidade operacional devido à alta lotação. O ar empoeirado urbano está explodindo os casos crônicos respiratórios nas pessoas e a rede de saúde se debruça sobre esgotamento físico de enfermeiros. Diretores e sindicatos param à frente da prefeitura demandando, com extrema urgência, que as autoridades sanitárias recebam socorro ou assinem os atestados de fatalidade nas longas filas de triagem.", "sistema de saude sobrecarregado.jpg",
            new Escolha("Incentivar fiscalmente a saúde privada", -5, +25, -15, -10,
            "Dando isenção violenta para convênios abrirem luxuosos centros privados, os altos empresários vibram. A economia movimenta rios de dinheiro em apólices e equipamentos. No entanto, os desfavorecidos respirando fuligem dos bairros industriais não têm acesso. Óbitos da base popular causam repúdio geral às castas curadas.\n\n -5 de Meio Ambiente \n +25 de Fundos Econômicos \n -15 de População \n -10 de Aprovação Pública"),

            new Escolha("Investir fortemente na saúde", +5, -35, +25, +25,
            "Milhões de reais puros são retirados com violência das reservas financeiras diretas do município para bancar horas extras, oxigênio novo e alas limpas para a plebe com asma e poluição. As contas do tesouro vão de arrasto no buraco vermelho da falência, mas todo paciente sobrevive e declara o prefeito como anjo sagrado.\n\n +5 de Meio Ambiente\n -35 de Fundos Econômicos\n +25 de População\n +25 de Aprovação Pública"),

            new Escolha("Melhorias básicas", +5, -15, +10, +10,
            "Cortando o pão pela metade, compras simples de insalubridade mínima e contratos temporários de estagiários ajudam. O caixa do governo leva um pequeno tranco controlável, oferecendo melhora modesta na capacidade de suporte à dor urbana que ainda tosse forte, pacificando pontualmente o pânico até as próximas chuvas limparem o ar.\n\n +5 de Meio Ambiente\n -15 de Fundos Econômicos\n +10 de População\n +10 de Aprovação Pública")
        ));

        eventos.add(new Evento("Graças ao cumprimento árduo de metas fiscais no semestre anterior estipuladas nacionalmente, a prefeitura acabou de receber uma transferência especial robusta, com a chegada silenciosa de um cheque pesado em verbas federais no cofre da cidade livre de laços formais. Isso lhe fornece autoridade suprema e imediata para alocar estes ganhos sem barreiras burocráticas no momento mais sensível de sua administração verde.", "Repasse econômico.jpg",
            new Escolha("Manter a verba", 0, +25, 0, 0,
            "Aplicando sabedoria gerencial fria, você aprisiona as cifras volumosas do cheque nas tesourarias estaduais de contingência gerando alta rentabilidade. O governo adquire solidez formidável e poderio blindado em tempos adversos futuros, ao custo de esconder completamente dos jornais qualquer centelha de obra majestosa.\n\n +25 de Fundos Econômicos"),

            new Escolha("Pagar um show de música gratuito", 0, -5, 0, +30,
            "Utilizando até uma lasca extra da reserva para turbinar, um megashow espetacular totalmente gratuito na praça principal faz todos delirarem por horas e gastarem com cervejeiros na calçada. O puro hedonismo festivo cativa absurdamente todos, convertendo o prêmio invisível numa arma de reeleição magnânima entre bebedeiras cívicas felizes.\n\n -5 de Fundos Econômicos\n +30 de Aprovação Pública"),

            new Escolha("Investir em modernização e corte de poluentes", +25, +10, +5, +15,
            "O orçamento abençoado custeia a virada dos pesados ônibus a diesel estatais para poderosos motores verdes e lâmpadas LEDs frias. Os rios voláteis do repasse viram tecnologia viva pura, gerando dividendos a médio prazo incríveis, salvando a coriza respiratória da infância e garantindo prosperidade popular brilhante ao município.\n\n +25 de Meio Ambiente\n +10 de Fundos Econômicos\n +5 de População\n +15 de Aprovação Pública")
        ));

        return eventos;
    }

    // Eventos de Meio Ambiente Alto 
    public static List<Evento> eventoAmbienteAlto() {
        List<Evento> eventoAmbienteAlto = new ArrayList<>();

        eventoAmbienteAlto.add(new Evento("URGENTE!!\n\nA ONU Global acabou de ratificar os papéis entregues atestando níveis maravilhosamente impecáveis de sua política urbana. A capital respira ar denso de campos frescos, as águas cintilantes encantam turistas, animais de faunas afastadas migraram para beijar o cimento ecológico das avenidas e os aplausos ressoam internacionalmente premiando seus incríveis feitos sobre a poluição mundial que tanto arruína outros.", "Ambiente Alto.jpg",
            new Escolha("Aproveitar o reconhecimento para atrair investimentos", +10, +25, +15, +15,
            "Montando palcos sedutores recheados de propaganda limpa no selo de paraíso urbano perfeito mundial as empresas gringas chegam derramando oceanos de barras de ouro buscando se instalar no reduto dos anjos de forma controlada. Ficam satisfeitos, ricos e limpos, arrastando corvos trabalhadores encantadores atrás das empresas brilhantes das novas fortunas de carbono zero erguidas sob sua coroa.\n\n +10 de Meio Ambiente\n +25 de Fundos Econômicos\n +15 de População\n +15 de Aprovação Pública"),

            new Escolha("Investir para se tornar referência global", +25, -35, +20, +20,
            "O radicalismo das plantas alcança o paroxismo absurdo forçando fundos inteiros de poupança estatais à zero para derrubar os prédios estatais brancos antigos erguendo verdadeiros cipós gigantes interligados tecnológicos absurdamente inovadores e orgânicos nas nuvens utópicas da floresta urbana. A terra brilha puríssima chamando legiões loucas e apaixonadas pela utopia esverdeada que devorou os fundos.\n\n +25 de Meio Ambiente\n -35 de Fundos Econômicos\n +20 de População\n +20 de Aprovação Pública"),

            new Escolha("Não investir mais e manter como está", -15, +10, -20, -20,
            "Achando de coração presunçoso que as estátuas já nasceram prontas e perfeitas, jardineiros da noite da folha perdem contratos caros economizando pequenas fatias ao erário. Ervas daninhas secas e asfalto com pequenas manchas esfriam a coroa maravilhosa dos noticiários, e quem se mudou pelo verde perfeito percebe a traição esburacada recuada nos impostos mesquinhos.\n\n -15 de Meio Ambiente\n +10 de Fundos Econômicos\n -20 de População\n -20 de Aprovação Pública")
        ));

        eventoAmbienteAlto.add(new Evento("URGENTE!!\n\nNossa impecável vitrine esmeralda não passou despercebida no cenário dos gigantes mundiais, os mandatários planetários exigem por meio de convites pomposos cravados nas cartas diplomáticas realizar o maior concílio ecológico da COP anual da terra aqui! A oportunidade impõe logística estelar absurda que abalaria tesourarias pesadas por conta de estandes enormes mas consagraria nosso nome nos livros magnos climáticos.", "Ambiente Alto 2.jpg",
            new Escolha("Recusar e manter estabilidade", -5, +5, -10, -15,
            "Fechando portas pesadas trancadas contra estrangeiros caros cobradores das logísticas colossais exigidas, as fortunas ficam protegidas do estourar contínuo dos gastos hoteleiros diplomáticos estatais pesados em jantares orgânicos. Ninguém desmata as praças limpas, mas corações internacionais perdem as esperanças nos corajosos da cidade amuada afundando o moral do palco principal mundial evitado.\n\n -5 de Meio Ambiente\n +5 de Fundos Econômicos\n -10 de População\n -15 de Aprovação Pública"),

            new Escolha("Firmar parcerias e dividir os custos", +10, -10, +10, +10,
            "Vendendo cotas corporativas ricas discretas, marcas globais bancam pavimentos bonitos recheados dos toldos protetores naturais que protegem as folhas e guardam moedas públicas limitadas do sangramento completo das despesas festivas magnas na hora estressante. Tudo termina bem aplaudido gerando fotos admiráveis de um passo forte de lideranças globais na casa arrumada modesta.\n\n +10 de Meio Ambiente\n -10 de Fundos Econômicos\n +10 de População\n +10 de Aprovação Pública"),

            new Escolha("Investir pesado para sediar o evento", +15, -25, +15, +15,
            "Arrancando verbas emergenciais profundas você ergue um palácio central transparente deslumbrante na montanha cercado da biologia avançada mundial acolhendo bilionários. As verbas rasgam-se ao meio amargando orçamentos de infraestruturas secundárias esquecidas na capital maravilhada pelos astros que abençoam cada centavo limpo verde abençoado aos corações de todos os nativos.\n\n +15 de Meio Ambiente\n -25 de Fundos Econômicos\n +15 de População\n +15 de Aprovação Pública")
        ));

        return eventoAmbienteAlto;
    }

    // Evento de Meio Ambiente Baixo 
    public static List<Evento> eventoAmbienteBaixo() {
        List<Evento> eventoAmbienteBaixo = new ArrayList<>();

        eventoAmbienteBaixo.add(new Evento("URGENTE!!\n\nUma nuvem corrosiva preta imensa afogou as luzes dos postes antes mesmo das tardes de sol desabrocharem e poças de óleo invadem os quintais dos trabalhadores enquanto a mortalidade e alergia varrem brutalmente as calçadas da amarga capital das tragédias poluídas sufocadas pela péssima logística deixada nas suas mãos. A humanidade morre junto das fábricas cuspindo alcatrão.",
            new Escolha("Implementar um plano emergencial de arborização e filtros urbanos", +20, -15, +5, +10,
            "Comprando e pendurando esponjas limpadoras artificiais enormes, cortando o mato morto urgente e espalhando regadores químicos amigáveis pelas praças destruídas num esforço frenético para tapar as crateras ácidas do céu usando ouro valioso público que deságua da riqueza governamental. Os bebês respiram leve de novo enquanto corações amargos engolem críticas para celebrar esse humilde alívio oxigenado dos prados artificiais montados.\n\n +20 de Meio Ambiente\n -15 de Fundos Econômicos\n +5 de População\n +10 de Aprovação Pública"),

            new Escolha("Maquiar os dados e focar em remédios para a população", -25, +10, -25, -35,
            "Escondendo perfeitamente os contadores negros falsificados das neves tóxicas das avenidas mentindo cinicamente que o asfalto é limpo enquanto lotam caminhões de pílulas calmas pagas às farmacêuticas sorridentes das moedas públicas roubadas secretamente e enchendo os fundos malditos imorais escondidos de sua maleta no horror da destruição cruel fúnebre do mato assassinado enforcando as almas raivosas caídas.\n\n -25 de Meio Ambiente\n +10 de Fundos Econômicos\n -25 de População\n -35 de Aprovação Pública"),

            new Escolha("Decretar lockdown industrial e multar severamente os poluidores", +35, -35, -15, +15,
            "Um chicote imperdoável amarrando todas as comportas metálicas poluidoras, você encerra as fábricas monstruosas e joga pesados cadeados da justiça aplicando severas multas falhas em quem ousa esfumaçar o ar doentio do município sufocando economias assalariadas completas caindo nos esgotos falidos forçando a dor do desemprego e êxodo massivo para trazer luz ao céu purificado limpíssimo salvador em forma doentia financeira dura na capital quebrada.\n\n +35 de Meio Ambiente\n -35 de Fundos Econômicos\n -15 de População\n +15 de Aprovação Pública")
        ));

        return eventoAmbienteBaixo;
    }

    //Evento de Economia Alta
    public static List<Evento> eventoEconomiaAlta() {
        List<Evento> eventoEconommiaAlta = new ArrayList<>();

        eventoEconommiaAlta.add(new Evento("URGENTE!!\n\nNenhuma lenda corporativa consegue segurar as cifras vertiginosas de alta produtividade das artérias entupidas de capital rolando nos distritos urbanos sob sua genialidade mercantil! Os rios de negócios fluem como cataratas derramadas dos caixas públicos cheios de excedentes arrecadados gerando especulação da fúria ambiciosa que busca onde engatar o foguete antes do boom financeiro abençoado virar pó ocioso esquecido na caderneta passiva do seu mandato sortudo.", "Economia Alta.jpg",
            new Escolha("Manter a situação atual", 0, +10, +5, -5,
            "Abraçando perfeitamente as poltronas da burocracia macia acumulando os ovos de ouros das taxas rentáveis pesadas e escondidas de investimentos explosivos arriscados as pastas contábeis vibram e o povo engorda na calma segurança das compras fartas, no entanto as multidões de grifes pedantes murmuram pela falta atrevida da agressividade megalomaníaca das grandes transformações deixadas de lado pela lerdeza burocrática dos cofres pesados preguiçosos intocáveis trancados nas prefeituras calmas.\n\n +10 de Fundos Econômicos\n +5 de População\n -5 de Aprovação Pública"),

            new Escolha("Expandir investimentos públicos", -10, -30, +25, +20,
            "Chovendo recursos fantásticos das arcas explodindo, brotam escolas perfeitas gigantes espelhadas de tijolos brancos limpos espantando a vida silvestre de cantos antigos varridos das bordas por pedreiros contentes abrindo alas imensas para mares de migrações empolgadas abraçando os postos públicos incríveis esvaziando metade do cofre acumulado gordo do passado mágico com risos sinceros das praças.\n\n -10 de Meio Ambiente\n -30 de Fundos Econômicos\n +25 de População\n +20 de Aprovação Pública"),

            new Escolha("Atrair mais empresas e ampliar a economia", -25, +35, +15, +10,
            "Arrastando corporações insanas para engolir matas vizinhas as garras mecânicas escavam a lama empilhando prédios bilionários doentios pesados na fuligem comercial da loucura capitalista triturando bosques florais lindos para rasgar contratos colossais multiplicando lucros fantásticos de fundos que chamam frotas de escravos das fábricas espremidas cimentadas nas calçadas ricas tristes do cinza eterno próspero.\n\n -25 de Meio Ambiente\n +35 de Fundos Econômicos\n +15 de População\n +10 de Aprovação Pública")
        ));

        return eventoEconommiaAlta;
    }
    
    //Evento de Economia Baixa
    public static List<Evento> eventoEconomiaBaixa() {
        List<Evento> eventoEconimiaBaixa = new ArrayList<>();

        eventoEconimiaBaixa.add(new Evento("URGENTE!!\n\nSangue e miséria nos papéis das planilhas das secretarias arrasadas. O mercado sucumbiu violentamente atirando as lixeiras de desempregados pelas vias e portas enferrujadas lacram indústrias caladas que morreram antes do inverno chegar! Sem arrecadar os míseros trocados das empresas mortas a tesouraria implora calada nos joelhos antes dos cobradores cortarem luzes do próprio hospital no próximo triste capítulo colapsado de sua falida coroa que apodrece na fome cinzenta.", "Economia Baixa.jpg",
            new Escolha("Aumentar impostos para recuperar os cofres", 0, +30, -20, -30,
            "Giratória impiedosa de cobranças rasgando carnês abusivos contra sobreviventes miseráveis você afoga as pequenas lojas sobreviventes atolando a classe média num poço doloroso arrancando até os fios dos bolsos furados resgatando das cinzas o saldo das contas estatais à custa de mães arrastando a família em ódios mortais aos limites imigratórios espantando a glória para o terrorismo odiado contra a bandeira fiscal cravada.\n\n +30 de Fundos Econômicos\n -20 de População\n -30 de Aprovação Pública"),

            new Escolha("Não intervir e esperar recuperação natural", 0, -25, -20, -25,
            "Escondido no escuro frio do pânico as portas não tem conserto, nenhuma obra vem as marretas descansam e os cofres perdem fundos esfarelados até zerar completamente de forma sombria e tenebrosa arrastando fantasmas desesperados famintos esvaindo rumo aos vizinhos de forma covarde deixando um legado podre e medonho destruído esquecido pelo próprio governante calado no buraco infernal covarde amedrontado que abandonou suas obrigações reais puras.\n\n -25 de Fundos Econômicos\n -20 de População\n -25 de Aprovação Pública"),

            new Escolha("Plano agressivo de recuperação econômica", -25, +40, +10, +15,
            "Chutando portões de parques rasgando as legislações em pedaços e incendiando licenças protetoras naturais para socorrer feras industriais loucas da poluição escandalosa suja desesperada oferecendo prêmios fiscais de salvação às madeireiras pesadas afundando a fauna ao cimento podre resgatando com fortunas monstruosas as mãos dos moradores sujos salvos adorando seus gritos brutais dos salários corrompidos das fuligens das chaminés agressivas loucas.\n\n -25 de Meio Ambiente\n +40 de Fundos Econômicos\n +10 de População\n +15 de Aprovação Pública")
        ));

        return eventoEconimiaBaixa;
    }

    // Evento de População Alta
    public static List<Evento> eventoPopulacaoAlta() {
        List<Evento> eventoPopulacaoAlta = new ArrayList<>();

        eventoPopulacaoAlta.add(new Evento("URGENTE!!\n\nNenhuma cadeira vaga resta nos ônibus espremidos, favelas incham feito veias aterrorizantes nas encostas desprotegidas e rios de cabeças empurram as calçadas de comércio estufadas de seres ofegantes da superpopulação das massas que buscaram as luzes da promessa metropolitana caindo no pior caos da civilização colapsada. Esgotos entopem, crianças pisoteiam sementes plantadas, as barricadas demográficas asfixiaram o leito doce orgânico tranquilo do munícipio.", "Popularidade alta.jpg",
            new Escolha("Cobrar uma taxa de imigração e novos moradores", 0, +25, -25, -20,
            "Tirania assinada brutal das muralhas de pedágios exigindo pacotes de verbas pesadas de aluguéis e licenças contra viajantes forasteiros varrendo os humildes dos sonhos arrastando bolsos com fortunas arrecadadoras e a revolta de famílias chorando divididas escorraçadas nos limites policiais do terror repulso cínico dos ditadores ricos trancados nas cercas da xenofobia de seu estado policial exclusivista feio e sombrio.\n\n +25 de Fundos Econômicos\n -25 de População\n -20 de Aprovação Pública"),

            new Escolha("Construir conjuntos habitacionais verticais rápidos", -25, -20, +25, +15,
            "Fincando garras ferozes nas áreas ricas de bosques os guindastes imensos despejam favelas de blocos infinitos gigantes espremendo pardieiros verticais abafados enfiados de famílias amontoadas rasgando o asfalto das calçadas afundando rios de montanhas com blocos colossais e afundando o bolso das taxas nas construções das torres maravilhas superlotadas do apocalipse verde aplaudidas e abraçadas pelos acolhidos gratos pela dignidade amarga dura urbana.\n\n -25 de Meio Ambiente\n -20 de Fundos Econômicos\n +25 de População\n +15 de Aprovação Pública"),

            new Escolha("Expandir o perímetro urbano sobre áreas verdes", -35, -15, +35, +20,
            "Os machados fatiam todas as bordas dos santuários floridos esticando violentamente os currais das quadras doentias infinitas que não acabam abrindo as pernas de fundos medianos da capital explodindo moradias e engolindo hordas assombrosas infinitas adoradoras da coroa abençoada das terras devastadas afundadas sob as rodas das serrarias cimentadas da periferia infinita que sangra lágrimas nas raízes caladas fúnebres destruídas pelas estradas monstruosas escuras.\n\n -35 de Meio Ambiente\n -15 de Fundos Econômicos\n +35 de População\n +20 de Aprovação Pública")
        ));

        return eventoPopulacaoAlta;
    }

    // Evento de População Baixa
    public static List<Evento> eventoPopulacaoBaixa() {
        List<Evento> eventoPopulacaoBaixa = new ArrayList<>();

        eventoPopulacaoBaixa.add(new Evento("URGENTE!!\n\nFolhas secas rodopiam solitárias caladas assombrosas nas esquinas vazias sem almas caminhantes das avenidas depressivas fantasmas das perdas massivas que afugentaram e sangraram vidas da metrópole abandonada. O luto das fábricas que imploram nos joelhos por braços mortos desaparecidos e vitrines mortas dos vendedores afundando faliu a civilização isolada sem esperança e abandonada sem sorrisos correndo dos parquinhos dos bairros da terra pálida moribunda solitária sem fôlego vital humano de ninguém nas calçadas de comércio podres.", "Popularidade Baixa.jpg",
            new Escolha("Não fazer nada e reduzir o tamanho dos serviços públicos", +20, +15, -20, -25,
            "Murchando caladas nas madrugadas cortando as fontes e escurecendo os postes você tranca secretarias e poupa a herança sagrada esticada das verbas intocáveis acumuladas abraçando capivaras soltas correndo dos rios aliviadas reconquistando as cinzas felizes mas marcando os diários sombrios das tristezas depressivas de rejeição maciça do exílio cruel dos idosos largados à morte nos bairros afastados fantasmagóricos afundando corações murchos dos lojistas tristes fechando as persianas finais mortais.\n\n +20 de Meio Ambiente\n +15 de Fundos Econômicos\n -20 de População\n -25 de Aprovação Pública"),

            new Escolha("Investir em automação e tecnologia para suprir a falta de pessoas", 0, -35, -5, +10,
            "Arrancando doentias tecnologias assombrosas importando dezenas de milhões sangrando as torneiras tristes dos cofres das estatais falidas trocando garis mecânicos de robôs que acendem os guichês dos comércios aliviando as engrenagens e paralisando as fugas estagnadas da urbe esquisita distópica sem sentimentos gelada mecânica das admirações curtas plásticas da ficção que tenta imitar e esconder o funeral macabro vazio sem seres orgânicos felizes nas praças inertes silenciosas mecânicas.\n\n -35 de Fundos Econômicos\n -5 de População\n +10 de Aprovação Pública"),

            new Escolha("Oferecer isenção de impostos e moradia grátis para novos imigrantes", -10, -30, +35, +15,
            "Explodindo propagandas nas galáxias rasgando os lotes vazios dos pássaros com as assinaturas de perdões absurdamente graciosos e torrando rios do tesouro estéril dos cofres das reservas explodindo as portas atiradas reanimando trens gigantes injetando os calores de vozes gargalhadas crianças felizes bagunçando o asfalto espantando lebrem correndo empolgadas adorando os deuses vivos felizes que ressuscitaram o fôlego milagroso das ruas das cidades aquecidas resgatadas dos abismos fúnebres sombrios passados tristes passados chorosos apagados da terra feliz cheia.\n\n -10 de Meio Ambiente\n -30 de Fundos Econômicos\n +35 de População\n +15 de Aprovação Pública")
        ));

        return eventoPopulacaoBaixa;
    }

    // Evento Aprovação Alta 
    public static List<Evento> eventoAprovacaoAlta() {
        List<Evento> eventoAprovacaoAlta = new ArrayList<>();

        eventoAprovacaoAlta.add(new Evento("URGENTE!!\n\nO instituto mais renomado do estado divulgou pesquisas assustadoramente positivas e sua aprovação está cruzando níveis jamais vistos. As praças o reverenciam, jornais cobrem seus sorrisos e conselheiros acreditam firmemente que você agora possui um 'cheque em branco' da paciência cidadã. É o dia mais tranquilo para empurrar grandes legislações ou colher glórias lentas.", "Aprovacao alta.png",
            new Escolha("Aprovar reformas econômicas estratégicas", -10, +30, +10, +10,
            "Utilizando táticas astutas para isentar burocracias sob aplausos contínuos, os empresários dominam e encharcam os bancos de transações gordas lucrativas. Máquinas trabalham forte enquanto árvores são esquecidas no ruído desenvolvimentista, empilhando vitórias industriais à custa das aves espantadas do território urbano.\n\n -10 de Meio Ambiente\n +30 de Fundos Econômicos\n +10 de População\n +10 de Aprovação Pública"),

            new Escolha("Manter a estabilidade e evitar riscos", 0, +10, +5, -5,
            "Buscando as calçadas calmas de domingos pacíficos, você tranca a agenda de reformas profundas. A economia anda com lentidão sólida enchendo potes modestos, a população fica satisfeita vivendo no platô do conforto sem medo. Contudo, alas ativistas de novidades suspiram com sono da monotonia gerencial caindo da moda.\n\n +10 de Fundos Econômicos\n +5 de População\n -5 de Aprovação Pública"),

            new Escolha("Lançar grandes projetos para a cidade", +10, -25, +20, +15,
            "Puxando alavancas que sugam violentamente os caixas trilionários guardados das pastas de serviços, os pilares de enormes centros culturais sustentáveis de madeira reflorestada invadem o céu municipal. Gente do mundo todo bate asas rumo ao seu jardim gigante metropolitano e cultuam uma administração magnânima que flerta com o abismo da própria falência utópica.\n\n +10 de Meio Ambiente\n -25 de Fundos Econômicos\n +20 de População\n +15 de Aprovação Pública")
        ));

        return eventoAprovacaoAlta;
    }

    // Evento Aprovação Baixa 
    public static List<Evento> eventoAprovacaoBaixa() {
        List<Evento> eventoAprovacaoBaixa = new ArrayList<>();

        eventoAprovacaoBaixa.add(new Evento("URGENTE!!\n\nIncêndios simbólicos devoram sua imagem: a cidade simplesmente detesta cada movimento seu e os níveis de ódio em pesquisas recentes fariam prefeitos covardes empacotarem as gavetas amedrontados. Barricadas fecham as esquinas enquanto gritos contra a administração varam a alvorada em protestos que abalam os lustres da cadeira governamental de seu próprio escritório acossado pela fúria de massa.", "Aprovacao Baixa.png",
            new Escolha("Ignorar e focar em alianças políticas nos bastidores", 0, +20, -15, -15,
            "Isolando o palácio das pedras populares atiradas das janelas vizinhas, você vende pedaços da honra a vereadores com concessões lucrativas espertas aos cofres frios. Enquanto as gavetas estouram moedas duras recuperadas politicamente, cidadãos honestos vomitam da tirania corrupta, fogem velozmente das malas amarradas na caçamba do táxi da repulsa profunda.\n\n +20 de Fundos Econômicos\n -15 de População\n -15 de Aprovação Pública"),

            new Escolha("Fazer um pronunciamento oficial prometendo bônus e auxílios", 0, -30, 0, +30,
            "Vestindo paletós brancos e chorando lágrimas artificiais com decretos assinados ao vivo na TV, as tesourarias da república são esfaqueadas liberando bolsas mensais, jantares baratos e tickets na rede. Toda a fúria das esquinas derrete veloz num sorridente amor dependente caro pelas moedas jogadas e a quebra assombra as sombras futuras amáveis.\n\n -30 de Fundos Econômicos\n +30 de Aprovação Pública"),

            new Escolha("Iniciar um grande mutirão de obras públicas para gerar empregos", -15, -20, +15, +20,
            "A resposta pesada traz caminhões sujos atirando pixe em estradas rasgadas mato adentro para abrir carteiras em branco das castas de trabalhadores fortes. Puxados pelo choro da broca rompendo o chão natural verde machucado e consumindo pacotes imensos de grana pública da emergência, o trabalhador focado exalta finalmente as mãos abertas de sua compaixão áspera com o pão assalariado trazido às pressas.\n\n -15 de Meio Ambiente\n -20 de Fundos Econômicos\n +15 de População\n +20 de Aprovação Pública")
        ));

        return eventoAprovacaoBaixa;
    }
}